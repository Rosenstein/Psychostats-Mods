<?php
$lang01['en'] = "Skill";
$lang01['ru'] = "Скилл";

$lang02['en'] = "Kills";
$lang02['ru'] = "Убийств";

$lang03['en'] = "Deaths";
$lang03['ru'] = "Смертей";

$lang04['en'] = "K/D rate";
$lang04['ru'] = "Соотн. У/С";

$lang05['en'] = "Accuracy";
$lang05['ru'] = "Точность";

$lang06['en'] = "Headshots";
$lang06['ru'] = "Хедшотов";

$lang07['en'] = "TOP weapon";
$lang07['ru'] = "TOP оружие";

$lang08['en'] = "TOP map";
$lang08['ru'] = "TOP карта";

$lang09['en'] = "Online time";
$lang09['ru'] = "В онлайне"; 

$lang10['en'] = "Teamkills";
$lang10['ru'] = "Тимкиллов"; 

$lang11['en'] = "Rank";
$lang11['ru'] = "Ранг"; 
?>