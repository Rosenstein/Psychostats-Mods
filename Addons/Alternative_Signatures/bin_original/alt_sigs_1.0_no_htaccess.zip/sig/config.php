<?php
// CONFIGURATION

// PSYCHOSTATS VERSION (3.1 or another)
$psycho = "3.1";

// LANGUAGE
$lang = "en";

// TITLE TEXT COLOR
$text_color_title = "#FFFFFF";

// TEXT COLOR
$text_color = "#000000";

// WEAPON BACKGROUND COLOR
$weapon_bg = "#FFFFFF";

// TITLE FONT
$font_title = "fonts/arialbd.ttf";

// FONT
$font = "fonts/arial.ttf";

// IMAGE WIDTH
$image_width = 350;

// IMAGE HEIGHT
$image_height = 100;
?>