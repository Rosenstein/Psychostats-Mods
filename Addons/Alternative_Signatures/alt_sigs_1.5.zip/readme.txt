/ ********** ENGLISH **********

Alternative Signatures for Psychostats !

Addon, which generates small images with your stats,

for using in signatures on forums, blogs, etc.

Addon also has templates and language system.

There are english and russian languages already included into addon.

To install:

Extract sig directory to your psychostats folder on web server. (e.x. http://yoursite.com/stats/sig/)

Open config.php in /sig/ folder, and change PSYCHOSTATS VERSION to your version (3.1 or another) and language (en or ru)

Open in browser /sig/install/install.php file and follow instructions.

After installion your signatures' paths should be like this:

http://yoursite.com/stats/sig/sig_1_2.png

/ ********** РУССКИЙ **********

Alternative Signatures для Psychostats !

Аддон, генерирующий небольшие картинки с вашей статистикой,

для использования в подписях на форумах, блогах и т.д.

Имеется система языков и скинов.

Поставляется с русским и английским языком.

Для установки:

Извлеките sig в вашу папку с Psychostats. (напр. http://yoursite.com/stats/sig/)

Откройте config.php, расположенный в /sig/, и измените $psycho на вашу версию Psychostats (3.1 или another) и $lang на желаемый язык (en или ru)

Откройте в браузере /sig/install/install.php и следуйте инструкциям.

После установки, путь до картинок должен выглядеть так:

http://yoursite.com/stats/sig/sig_1_2.png

Version: 1.5

---------------------------

Author: 3D-GRAF a.k.a F1NAL

E-mail: denkil92@mail.ru

ICQ#: 751306