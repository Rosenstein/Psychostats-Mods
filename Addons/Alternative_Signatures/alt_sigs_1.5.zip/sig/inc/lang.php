<?php
$lang01['en'] = "Skill";
$lang01['ru'] = "Скилл";
$lang01['sv'] = "Skill";

$lang02['en'] = "Kills";
$lang02['ru'] = "Убито";
$lang02['sv'] = "Dödat";

$lang03['en'] = "Deaths";
$lang03['ru'] = "Смертей";
$lang03['sv'] = "Dödsfall";

$lang04['en'] = "K/D rate";
$lang04['ru'] = "Соотн. У/С";
$lang04['sv'] = "K/D ratio";

$lang05['en'] = "Accuracy";
$lang05['ru'] = "Точность";
$lang05['sv'] = "Precision";

$lang06['en'] = "Headshots";
$lang06['ru'] = "В голову";
$lang06['sv'] = "Huvudskott";

$lang07['en'] = "TOP weapon";
$lang07['ru'] = "TOP оружие";
$lang07['sv'] = "TOP vapen";

$lang08['en'] = "TOP map";
$lang08['ru'] = "TOP карта";
$lang08['sv'] = "TOP bana";

$lang09['en'] = "Online time";
$lang09['ru'] = "В онлайне";
$lang09['sv'] = "Tid Online";

$lang10['en'] = "Shots";
$lang10['ru'] = "Выстрелов";
$lang10['sv'] = "Skott";

$lang11['en'] = "Rank";
$lang11['ru'] = "Ранг";
$lang11['sv'] = "Rank";

$lang12['en'] = "Hits";
$lang12['ru'] = "Попаданий";
$lang12['sv'] = "Träffar";

$lang13['en'] = "Psychostats web-statistics of server";
$lang13['ru'] = "Psychostats веб-статистика сервера";
$lang13['sv'] = "Psychostats Web-Statistik från servern";
?>